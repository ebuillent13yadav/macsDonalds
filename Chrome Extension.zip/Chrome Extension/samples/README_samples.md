# Sample files

- `sample.txt` — ~10 KB lorem ipsum (text/gzip path)
- `sample.png` — 512×512 synthetic image (lossless UPNG path)
- `sample.jpg` — same image as JPEG (lossy canvas path)
- `sample.wav` — 3-second 44.1 kHz stereo chord (audio/MP3 path)
- Video: bring your own short `.mp4` / `.webm` (< 200 MB). The extension uses `MediaRecorder` which runs in real time, so a 30-second clip takes ~30 seconds to re-encode.
