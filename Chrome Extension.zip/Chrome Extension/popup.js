// ─────────────────────────────────────────────────────────────────────────────
// Constants & shared state
// ─────────────────────────────────────────────────────────────────────────────

const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024;

/**
 * Runtime state shared across compress / decompress flows.
 * hashStore maps a compressed filename → original SHA-256 so the
 * decompress tab can do a full round-trip verification in the same session.
 * originalFileStore maps a compressed filename → the original File object
 * so PSNR can be recalculated on the decompress tab.
 */
const state = {
  compressedBlob: null,
  decompressedBlob: null,
  processedBlob: null,
  compressedName: '',
  decompressedName: '',
  processedName: '',
  hashStore: {},          // compressedName → originalHash (lossless round-trip)
  originalFileStore: {},  // compressedName → original File object (lossy PSNR)
};

// ─────────────────────────────────────────────────────────────────────────────
// DOM element references
// ─────────────────────────────────────────────────────────────────────────────

const elements = {
  compressTab: document.getElementById('compressTab'),
  decompressTab: document.getElementById('decompressTab'),
  compressForm: document.getElementById('compressForm'),
  decompressForm: document.getElementById('decompressForm'),
  inputFile: document.getElementById('inputFile'),
  compressedInput: document.getElementById('compressedInput'),
  imageQuality: document.getElementById('imageQuality'),
  imageQualityValue: document.getElementById('imageQualityValue'),
  mediaBitrateFactor: document.getElementById('mediaBitrateFactor'),
  mediaBitrateValue: document.getElementById('mediaBitrateValue'),
  status: document.getElementById('status'),
  errorBox: document.getElementById('errorBox'),
  resultsPanel: document.getElementById('resultsPanel'),
  detectedTypeBadge: document.getElementById('detectedTypeBadge'),
  originalSize: document.getElementById('originalSize'),
  compressedSize: document.getElementById('compressedSize'),
  compressionRatio: document.getElementById('compressionRatio'),
  spaceSavings: document.getElementById('spaceSavings'),
  verificationList: document.getElementById('verificationList'),
  downloadCompressed: document.getElementById('downloadCompressed'),
  downloadDecompressed: document.getElementById('downloadDecompressed'),
  decompressPanel: document.getElementById('decompressPanel'),
  decompressBadge: document.getElementById('decompressBadge'),
  decompressOutput: document.getElementById('decompressOutput'),
  downloadProcessed: document.getElementById('downloadProcessed'),
};

// ─────────────────────────────────────────────────────────────────────────────
// Initialisation
// ─────────────────────────────────────────────────────────────────────────────

init();

/** Wires up all event listeners and restores stored slider preferences. */
function init() {
  bindModeSwitching();
  bindInputs();
  bindActions();
  restorePreferences();
}

/** Switches the visible tab when the user clicks Compress / Decompress. */
function bindModeSwitching() {
  elements.compressTab.addEventListener('click', () => setActiveMode('compress'));
  elements.decompressTab.addEventListener('click', () => setActiveMode('decompress'));
}

/** Binds slider display updates and form submit handlers. */
function bindInputs() {
  elements.imageQuality.addEventListener('input', () => {
    elements.imageQualityValue.textContent = Number(elements.imageQuality.value).toFixed(2);
  });
  elements.mediaBitrateFactor.addEventListener('input', () => {
    elements.mediaBitrateValue.textContent = Number(elements.mediaBitrateFactor.value).toFixed(2);
  });
  elements.compressForm.addEventListener('submit', onCompressSubmit);
  elements.decompressForm.addEventListener('submit', onDecompressSubmit);
}

/** Binds the three download buttons to their respective stored blobs. */
function bindActions() {
  elements.downloadCompressed.addEventListener('click', () => {
    if (state.compressedBlob) downloadBlob(state.compressedBlob, state.compressedName || 'compressed-output');
  });
  elements.downloadDecompressed.addEventListener('click', () => {
    if (state.decompressedBlob) downloadBlob(state.decompressedBlob, state.decompressedName || 'decompressed-output');
  });
  elements.downloadProcessed.addEventListener('click', () => {
    if (state.processedBlob) downloadBlob(state.processedBlob, state.processedName || 'processed-output');
  });
}

/**
 * Loads saved slider values from chrome.storage and persists future changes
 * so the user's preferences survive popup close/reopen.
 */
async function restorePreferences() {
  const defaults = { imageQuality: '0.75', mediaBitrateFactor: '0.65' };
  const stored = await chrome.storage.local.get(defaults);
  elements.imageQuality.value = stored.imageQuality;
  elements.mediaBitrateFactor.value = stored.mediaBitrateFactor;
  elements.imageQualityValue.textContent = Number(stored.imageQuality).toFixed(2);
  elements.mediaBitrateValue.textContent = Number(stored.mediaBitrateFactor).toFixed(2);
  elements.imageQuality.addEventListener('change', () =>
    chrome.storage.local.set({ imageQuality: elements.imageQuality.value }));
  elements.mediaBitrateFactor.addEventListener('change', () =>
    chrome.storage.local.set({ mediaBitrateFactor: elements.mediaBitrateFactor.value }));
}

/**
 * Switches the active mode tab and form panel.
 * @param {'compress'|'decompress'} mode
 */
function setActiveMode(mode) {
  const isCompress = mode === 'compress';
  elements.compressTab.classList.toggle('active', isCompress);
  elements.decompressTab.classList.toggle('active', !isCompress);
  elements.compressForm.classList.toggle('active', isCompress);
  elements.decompressForm.classList.toggle('active', !isCompress);

  // Compression results only show on Compress.
  // Decompression / inspection results only show on Decompress.
  elements.resultsPanel.classList.toggle('hidden', !isCompress || !state.compressedBlob);
  elements.decompressPanel.classList.toggle('hidden', isCompress || !state.processedBlob);
  clearError();
}

// ─────────────────────────────────────────────────────────────────────────────
// Compress flow
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handles the Compress form submission. Detects file type, runs the
 * appropriate compressor, and renders results + download buttons.
 * @param {SubmitEvent} event
 */
async function onCompressSubmit(event) {
  event.preventDefault();
  clearError();
  resetCompressionState();
  elements.decompressPanel.classList.add('hidden');
  const file = elements.inputFile.files?.[0];
  if (!file) return showError('Please choose a file to compress.');
  if (file.size > MAX_FILE_SIZE_BYTES) return showError('File too large. Please keep files under 100 MB.');
  try {
    setStatus(`Compressing ${file.name}…`);
    const typeInfo = detectFileType(file);
    const result = await compressByType(file, typeInfo);
    renderCompressionResult(file, typeInfo, result);
    setStatus(`Compression complete for ${file.name}.`);
  } catch (error) {
    console.error(error);
    showError(error.message || 'Compression failed.');
    setStatus('Compression failed.');
  }
}

/**
 * Detects the logical file category and lossless/lossy mode from name and MIME.
 * @param {File} file
 * @returns {{ category: string, extension: string, typeLabel: string, lossless: boolean }}
 */
function detectFileType(file) {
  const name = file.name.toLowerCase();
  const extension = name.includes('.') ? name.split('.').pop() : '';
  const mime = (file.type || '').toLowerCase();

  if (['txt', 'csv'].includes(extension))
    return { category: 'text', extension, typeLabel: 'Text / Lossless', lossless: true };

  if (['png', 'jpg', 'jpeg'].includes(extension) || mime.startsWith('image/')) {
    const isPng = extension === 'png' || mime === 'image/png';
    return {
      category: 'image',
      extension: isPng ? 'png' : 'jpg',
      typeLabel: isPng ? 'PNG / Lossless' : 'JPEG / Lossy',
      lossless: isPng,
    };
  }

  if (['wav', 'mp3'].includes(extension) || mime.startsWith('audio/'))
    return { category: 'audio', extension, typeLabel: extension === 'wav' ? 'WAV to MP3 / Lossy' : 'MP3 / Optimized', lossless: false };

  if (extension === 'mp4' || extension === 'webm' || mime.startsWith('video/'))
    return { category: 'video', extension: extension === 'webm' ? 'webm' : 'mp4', typeLabel: 'Video / Lossy (WebM output)', lossless: false };

  if (extension === 'gz')
    return { category: 'gzip', extension, typeLabel: 'GZIP Archive', lossless: true };

  throw new Error(`Unsupported file type: .${extension || 'unknown'}`);
}

/**
 * Routes a file to the correct compression function based on detected type.
 * @param {File} file
 * @param {{ category: string, extension: string }} typeInfo
 */
async function compressByType(file, typeInfo) {
  switch (typeInfo.category) {
    case 'text':  return compressTextFile(file);
    case 'image': return compressImageFile(file, typeInfo.extension);
    case 'audio': return compressAudioFile(file, typeInfo.extension);
    case 'video': return compressVideoFile(file);
    default: throw new Error('No compressor available for this file type.');
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Text compression  (GZIP / lossless)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compresses a text/CSV file with GZIP (pako level 9).
 * Immediately verifies the round-trip by ungzipping and comparing SHA-256.
 * Falls back to the original file if GZIP makes it larger.
 * @param {File} file
 */
async function compressTextFile(file) {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const gzipBytes = pako.gzip(bytes, { level: 9 });
  const originalHash = await sha256Hex(buffer);

  // Verify round-trip immediately
  const rebuiltBytes = pako.ungzip(gzipBytes);
  // pako may return a view into a larger backing buffer — slice to exact bytes
  const rebuiltBuffer = rebuiltBytes.buffer.slice(
    rebuiltBytes.byteOffset, rebuiltBytes.byteOffset + rebuiltBytes.byteLength);
  const rebuiltBlob = new Blob([rebuiltBuffer], { type: file.type || guessMimeFromName(file.name) || 'text/plain' });

  const archiveBlob = new Blob([gzipBytes], { type: 'application/gzip' });
  const passthrough = archiveBlob.size >= file.size;
  const compressedBlob = passthrough ? file : archiveBlob;
  const compressedName = passthrough ? file.name : `${file.name}.gz`;

  return {
    compressedBlob,
    compressedName,
    decompressedBlob: rebuiltBlob,
    decompressedName: file.name,
    verification: {
      mode: 'lossless',
      originalHash,
      rebuiltHash: await sha256Hex(rebuiltBuffer),
      note: passthrough
        ? 'File is too small or incompressible — original kept to avoid size increase.'
        : 'Compressed with GZIP level 9. Round-trip verified.',
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Image compression  (PNG lossless / JPEG lossy)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compresses a PNG or JPEG image.
 * PNG: re-encodes with UPNG.js for lossless size reduction.
 * JPEG: re-encodes via OffscreenCanvas at the user-selected quality.
 * Stores the original File in state.originalFileStore so the decompress tab
 * can recalculate PSNR against the same original.
 * @param {File} file
 * @param {'png'|'jpg'} extension
 */
async function compressImageFile(file, extension) {
  const imageBitmap = await createImageBitmap(file);
  const { width, height } = imageBitmap;
  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not create image canvas context.');
  ctx.drawImage(imageBitmap, 0, 0);

  const originalBuffer = await file.arrayBuffer();
  const originalHash = await sha256Hex(originalBuffer);
  let outputBlob;

  if (extension === 'png') {
    // Attempt lossless UPNG re-compression; fall back to native canvas PNG
    const imageData = ctx.getImageData(0, 0, width, height);
    const pngBytes = window.UPNG?.encode
      ? window.UPNG.encode([imageData.data.buffer], width, height, 0)
      : null;
    outputBlob = pngBytes
      ? new Blob([pngBytes], { type: 'image/png' })
      : await canvas.convertToBlob({ type: 'image/png' });
  } else {
    outputBlob = await canvas.convertToBlob({
      type: 'image/jpeg',
      quality: Number(elements.imageQuality.value),
    });
  }

  // If re-encoding made the file larger, keep the original bytes
  const useOriginal = outputBlob.size >= file.size;
  const finalBlob = useOriginal ? file : outputBlob;
  const finalName = useOriginal
    ? file.name
    : buildOutputName(file.name, extension === 'png' ? 'compressed.png' : 'compressed.jpg');
  const finalBuffer = await finalBlob.arrayBuffer();

  // PNG hashes should match (lossless). JPEG won't match (lossy).
  const psnr = extension === 'jpg' && !useOriginal
    ? await calculatePsnrFromImages(file, finalBlob)
    : null;

  const verification = extension === 'png'
    ? {
        mode: 'lossless',
        originalHash,
        rebuiltHash: await sha256Hex(finalBuffer),
        note: useOriginal
          ? 'PNG was already fully optimized — original kept.'
          : 'PNG recompressed with UPNG.js (lossless filter and deflate tuning).',
      }
    : {
        mode: 'lossy',
        psnr: useOriginal ? Infinity : psnr,
        bitrateComparison: `${formatBytes(file.size)} → ${formatBytes(finalBlob.size)}`,
        note: useOriginal
          ? 'JPEG re-encoding did not reduce size at this quality setting — original kept.'
          : `JPEG re-encoded at quality ${Number(elements.imageQuality.value).toFixed(2)}. JPEG is lossy — exact pixel recovery is not possible.`,
      };

  // Cache the original file so the decompress tab can run PSNR on it
  state.originalFileStore[finalName] = file;

  return {
    compressedBlob: finalBlob,
    compressedName: finalName,
    decompressedBlob: finalBlob,
    decompressedName: useOriginal
      ? file.name
      : buildOutputName(file.name, extension === 'png' ? 'rebuilt.png' : 'rebuilt.jpg'),
    verification,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Audio compression  (WAV → MP3 / MP3 → MP3)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Routes audio files to the correct encoder path based on extension.
 * @param {File} file
 * @param {'wav'|'mp3'} extension
 */
async function compressAudioFile(file, extension) {
  return extension === 'wav' ? compressWavToMp3(file) : compressMp3ToMp3(file);
}

/**
 * Re-encodes an MP3 file at a lower bitrate using lamejs.
 * Estimates original bitrate from file size + duration, then targets a
 * meaningfully lower standard bitrate snapped to lamejs-supported values.
 * @param {File} file
 */
async function compressMp3ToMp3(file) {
  if (!window.lamejs) throw new Error('lamejs library is not available.');
  const audioContext = new AudioContext();
  const arrayBuffer = await file.arrayBuffer();
  const decoded = await audioContext.decodeAudioData(arrayBuffer.slice(0));
  const duration = decoded.duration || 1;
  const originalKbps = Math.max(64, Math.round((file.size * 8) / 1000 / duration));
  const factor = Number(elements.mediaBitrateFactor.value);
  let targetKbps = Math.min(Math.round(originalKbps * factor), Math.round(originalKbps * 0.8));
  const validKbps = [64, 80, 96, 112, 128, 160, 192, 224, 256, 320];
  targetKbps = validKbps.reduce((best, v) =>
    Math.abs(v - targetKbps) < Math.abs(best - targetKbps) ? v : best, validKbps[0]);
  if (targetKbps >= originalKbps)
    targetKbps = Math.max(64, validKbps[Math.max(0, validKbps.indexOf(targetKbps) - 1)]);

  const channels = Math.min(decoded.numberOfChannels, 2);
  const sampleRate = decoded.sampleRate;
  const encoder = new lamejs.Mp3Encoder(channels, sampleRate, targetKbps);
  const left = floatTo16BitPCM(decoded.getChannelData(0));
  const right = channels > 1 ? floatTo16BitPCM(decoded.getChannelData(1)) : null;
  const chunkSize = 1152;
  const mp3Chunks = [];
  for (let offset = 0; offset < left.length; offset += chunkSize) {
    const leftChunk = left.subarray(offset, offset + chunkSize);
    const encodedChunk = channels > 1
      ? encoder.encodeBuffer(leftChunk, right.subarray(offset, offset + chunkSize))
      : encoder.encodeBuffer(leftChunk);
    if (encodedChunk.length > 0) mp3Chunks.push(new Uint8Array(encodedChunk));
  }
  const finalChunk = encoder.flush();
  if (finalChunk.length > 0) mp3Chunks.push(new Uint8Array(finalChunk));
  await audioContext.close();

  const outputBlob = new Blob(mp3Chunks, { type: 'audio/mpeg' });
  const grew = outputBlob.size >= file.size;
  return {
    compressedBlob: grew ? file : outputBlob,
    compressedName: grew ? file.name : buildOutputName(file.name, `${targetKbps}kbps.mp3`),
    decompressedBlob: grew ? file : outputBlob,
    decompressedName: grew ? file.name : buildOutputName(file.name, 'preview.mp3'),
    verification: {
      mode: 'lossy',
      bitrateComparison: `${originalKbps} kbps → ${targetKbps} kbps`,
      note: grew
        ? `Source is already at or below ${targetKbps} kbps — try lowering the bitrate factor.`
        : `Re-encoded with lamejs at ${targetKbps} kbps (${channels} ch, ${sampleRate} Hz). MP3 is lossy.`,
    },
  };
}

/**
 * Converts an uncompressed WAV file to MP3 using lamejs.
 * Uses Web Audio API to decode PCM, then encodes at a target bitrate
 * derived from the slider value.
 * @param {File} file
 */
async function compressWavToMp3(file) {
  if (!window.lamejs) throw new Error('lamejs library is not available.');
  const audioContext = new AudioContext();
  const arrayBuffer = await file.arrayBuffer();
  const decoded = await audioContext.decodeAudioData(arrayBuffer.slice(0));
  const channels = Math.min(decoded.numberOfChannels, 2);
  const sampleRate = decoded.sampleRate;
  const bitrate = Math.max(64, Math.round(192 * Number(elements.mediaBitrateFactor.value)));
  const encoder = new lamejs.Mp3Encoder(channels, sampleRate, bitrate);
  const left = floatTo16BitPCM(decoded.getChannelData(0));
  const right = channels > 1 ? floatTo16BitPCM(decoded.getChannelData(1)) : null;
  const chunkSize = 1152;
  const mp3Chunks = [];
  for (let offset = 0; offset < left.length; offset += chunkSize) {
    const leftChunk = left.subarray(offset, offset + chunkSize);
    const encodedChunk = channels > 1
      ? encoder.encodeBuffer(leftChunk, right.subarray(offset, offset + chunkSize))
      : encoder.encodeBuffer(leftChunk);
    if (encodedChunk.length > 0) mp3Chunks.push(new Uint8Array(encodedChunk));
  }
  const finalChunk = encoder.flush();
  if (finalChunk.length > 0) mp3Chunks.push(new Uint8Array(finalChunk));
  await audioContext.close();

  const outputBlob = new Blob(mp3Chunks, { type: 'audio/mpeg' });
  const useOriginal = outputBlob.size >= file.size;
  const finalBlob = useOriginal ? file : outputBlob;
  return {
    compressedBlob: finalBlob,
    compressedName: useOriginal ? file.name : buildOutputName(file.name, 'compressed.mp3'),
    decompressedBlob: finalBlob,
    decompressedName: useOriginal ? file.name : buildOutputName(file.name, 'preview.mp3'),
    verification: {
      mode: 'lossy',
      bitrateComparison: `${guessMediaBitrate(file)} → ${useOriginal ? guessMediaBitrate(file) : `${bitrate} kbps target`}`,
      note: useOriginal
        ? 'WAV to MP3 conversion did not beat the original size — original kept.'
        : 'WAV encoded to MP3 with lamejs. Lossy — exact hash match is not expected.',
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Video compression  (MP4 / WebM → WebM via MediaRecorder)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Re-encodes an MP4 or WebM video to WebM at a lower bitrate using
 * MediaRecorder + captureStream().
 *
 * CRITICAL: The video element MUST be appended to document.body before
 * captureStream() is called. Chrome only allocates a real hardware decode
 * and capture pipeline for elements that are in the live DOM. A detached
 * element returns an empty stream that produces zero bytes.
 *
 * The element is hidden via inline CSS (1px, opacity 0.01) and removed
 * from the DOM as soon as recording stops.
 *
 * @param {File} file
 */
async function compressVideoFile(file) {
  return new Promise((resolve, reject) => {

    // ── Attach to DOM so captureStream gets a real pipeline ──────────────────
    const video = document.createElement('video');
    video.style.cssText = 'position:absolute;width:1px;height:1px;opacity:0.01;pointer-events:none;left:0;top:0;';
    video.preload = 'auto';
    video.muted = true;
    video.playsInline = true;
    document.body.appendChild(video);

    const objectUrl = URL.createObjectURL(file);
    video.src = objectUrl;

    const cleanup = () => {
      try { video.pause(); } catch (_) { /* ignore */ }
      if (video.parentNode) video.parentNode.removeChild(video);
      URL.revokeObjectURL(objectUrl);
    };

    video.onerror = () => {
      cleanup();
      reject(new Error('Could not decode the video file. Unsupported codec or corrupt file.'));
    };

    video.onloadedmetadata = () => {
      const duration = video.duration;
      if (!isFinite(duration) || duration <= 0) {
        cleanup();
        reject(new Error('Could not read video duration. The file may be streamed or corrupt.'));
        return;
      }

      // Compute target bitrate — always meaningfully below source so output shrinks
      const originalBps = Math.round((file.size * 8) / duration);
      const effectiveFactor = Math.min(Number(elements.mediaBitrateFactor.value), 0.85);
      const videoBitsPerSecond = Math.max(250_000, Math.round(originalBps * effectiveFactor));

      // Pick best supported WebM codec
      const candidates = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=vp9',
        'video/webm;codecs=vp8',
        'video/webm',
      ];
      const mimeType = candidates.find((m) => MediaRecorder.isTypeSupported(m));
      if (!mimeType) {
        cleanup();
        reject(new Error('This browser does not support any WebM MediaRecorder codec.'));
        return;
      }

      // captureStream() requires the element to be in the live DOM (done above)
      let stream;
      try {
        stream = video.captureStream ? video.captureStream() : video.mozCaptureStream();
      } catch (err) {
        cleanup();
        reject(new Error(`captureStream() failed: ${err.message}`));
        return;
      }
      if (!stream || stream.getTracks().length === 0) {
        cleanup();
        reject(new Error('captureStream() returned an empty stream. Try a different video file or check for DRM protection.'));
        return;
      }

      const chunks = [];
      let recorder;
      try {
        recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond, audioBitsPerSecond: 96_000 });
      } catch (err) {
        cleanup();
        reject(new Error(`Could not create MediaRecorder: ${err.message}`));
        return;
      }

      recorder.ondataavailable = (evt) => {
        if (evt.data && evt.data.size > 0) chunks.push(evt.data);
      };

      recorder.onerror = (evt) => {
        cleanup();
        reject(new Error(`Recorder error: ${evt.error?.message || 'unknown'}`));
      };

      // Safety timeout stops recording if onended never fires (e.g. loop=true)
      const safetyTimer = setTimeout(() => {
        if (recorder.state === 'recording') recorder.stop();
      }, (duration + 5) * 1000);

      recorder.onstop = () => {
        clearTimeout(safetyTimer);
        cleanup();

        if (chunks.length === 0) {
          reject(new Error(
            'MediaRecorder produced no output data. ' +
            'This usually means the video is DRM-protected or uses a hardware-only codec. ' +
            'Try a different MP4 file.'
          ));
          return;
        }

        const containerType = mimeType.split(';')[0];
        const outBlob = new Blob(chunks, { type: containerType });
        const grew = outBlob.size >= file.size;
        const finalBlob = grew ? file : outBlob;
        const finalName = grew ? file.name : buildOutputName(file.name, 'compressed.webm');
        const originalKbps = Math.round(originalBps / 1000);
        const targetKbps = Math.round(videoBitsPerSecond / 1000);
        const codecTag = mimeType.includes('vp9') ? 'VP9' : (mimeType.includes('vp8') ? 'VP8' : 'WebM');

        resolve({
          compressedBlob: finalBlob,
          compressedName: finalName,
          decompressedBlob: finalBlob,
          decompressedName: finalName,
          verification: {
            mode: 'lossy',
            bitrateComparison: `${originalKbps} kbps (source) → ${targetKbps} kbps (${codecTag}/webm)`,
            note: grew
              ? 'Re-encoded output was not smaller than the source. Try a lower bitrate factor.'
              : `Re-encoded to WebM (${codecTag}+Opus) at ~${targetKbps} kbps. ` +
                'Container changed from MP4 to WebM because Chrome MediaRecorder cannot emit MP4.',
          },
        });
      };

      video.onended = () => {
        if (recorder.state === 'recording') recorder.stop();
      };

      setStatus(`Re-encoding video (${Math.round(duration)} s at real-time speed)…`);
      recorder.start(250); // emit a data chunk every 250 ms
      video.play().catch((err) => {
        cleanup();
        reject(new Error(`Could not start video playback: ${err.message}`));
      });
    };
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PCM helper for lamejs
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Converts a Float32 PCM channel array to Int16 as required by lamejs.
 * @param {Float32Array} float32Array
 * @returns {Int16Array}
 */
function floatTo16BitPCM(float32Array) {
  const output = new Int16Array(float32Array.length);
  for (let i = 0; i < float32Array.length; i += 1) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return output;
}

// ─────────────────────────────────────────────────────────────────────────────
// Result rendering
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Renders compression metrics and enables download buttons.
 * Caches the original hash in state.hashStore and the original File in
 * state.originalFileStore so the decompress tab can run full verification.
 * @param {File} originalFile
 * @param {{ typeLabel: string }} typeInfo
 * @param {object} result
 */
function renderCompressionResult(originalFile, typeInfo, result) {
  elements.resultsPanel.classList.remove('hidden');
  elements.detectedTypeBadge.textContent = typeInfo.typeLabel;
  elements.originalSize.textContent = formatBytes(originalFile.size);
  elements.compressedSize.textContent = formatBytes(result.compressedBlob.size);
  elements.compressionRatio.textContent = formatCompressionRatio(originalFile.size, result.compressedBlob.size);
  elements.spaceSavings.textContent = formatSpaceSavings(originalFile.size, result.compressedBlob.size);

  state.compressedBlob = result.compressedBlob;
  state.compressedName = result.compressedName;
  state.decompressedBlob = result.decompressedBlob || null;
  state.decompressedName = result.decompressedName || '';
  elements.downloadCompressed.disabled = false;
  elements.downloadDecompressed.disabled = !result.decompressedBlob;

  // Cache original hash so decompress tab can show a full match
  if (result.verification?.originalHash && result.compressedName) {
    state.hashStore[result.compressedName] = result.verification.originalHash;
  }

  renderVerification(result.verification);
}

/**
 * Populates the Verification list with lossless hash info or lossy quality metrics.
 * @param {{ mode: string, originalHash?: string, rebuiltHash?: string, psnr?: number, bitrateComparison?: string, note?: string }} v
 */
function renderVerification(v) {
  elements.verificationList.innerHTML = '';

  if (v.mode === 'lossless') {
    appendVerificationItem(`Original SHA-256: ${v.originalHash}`);
    appendVerificationItem(`Rebuilt SHA-256:  ${v.rebuiltHash}`);
    appendVerificationItem(`Exact match: ${v.originalHash === v.rebuiltHash ? '✅ Yes — perfect round-trip' : '❌ No — data differs'}`);
    if (v.note) appendVerificationItem(v.note);
    return;
  }

  if (Number.isFinite(v.psnr)) {
    const label = v.psnr === Infinity
      ? 'Infinite (no pixel change)'
      : `${v.psnr.toFixed(2)} dB${v.psnr >= 40 ? ' — excellent' : v.psnr >= 30 ? ' — good' : ' — noticeable loss'}`;
    appendVerificationItem(`PSNR: ${label}`);
  }
  if (v.bitrateComparison) appendVerificationItem(`Size / bitrate: ${v.bitrateComparison}`);
  if (v.note) appendVerificationItem(v.note);
}

/**
 * Appends a single item to the verification list.
 * @param {string} text
 */
function appendVerificationItem(text) {
  const li = document.createElement('li');
  li.textContent = text;
  elements.verificationList.appendChild(li);
}

// ─────────────────────────────────────────────────────────────────────────────
// Decompress / Inspect flow
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handles the Decompress form submission. Routes the uploaded file through
 * decompressOrInspect() and renders the result panel + download button.
 * @param {SubmitEvent} event
 */
async function onDecompressSubmit(event) {
  event.preventDefault();
  clearError();
  resetDecompressionState();
  elements.resultsPanel.classList.add('hidden');

  const file = elements.compressedInput.files?.[0];
  if (!file) return showError('Please choose a compressed or media file to inspect.');
  if (file.size > MAX_FILE_SIZE_BYTES) return showError('File too large. Please keep files under 100 MB.');

  try {
    setStatus(`Processing ${file.name}…`);
    const inspection = await decompressOrInspect(file);
    elements.decompressPanel.classList.remove('hidden');
    elements.decompressBadge.textContent = inspection.typeLabel;
    elements.decompressOutput.innerHTML = inspection.message;
    state.processedBlob = inspection.outputBlob || null;
    state.processedName = inspection.outputName || '';
    elements.downloadProcessed.disabled = !inspection.outputBlob;
    setStatus(`Done — ${file.name} processed successfully.`);
  } catch (error) {
    console.error(error);
    showError(error.message || 'Could not process file.');
    setStatus('Decompression / inspection failed.');
  }
}

/**
 * Core decompression and inspection router.
 *
 * Lossless formats (.gz, .fcs, PNG, plain text):
 *   Fully decompresses and verifies with SHA-256. If the file was compressed
 *   in the same session, shows a full original vs rebuilt hash comparison.
 *
 * Lossy formats (JPEG, MP3, WebM, MP4):
 *   These cannot be reversed to the original bytes — the output IS the
 *   compressed file. This function inspects metadata (dimensions, duration,
 *   bitrate) and enables the user to download the file as-is.
 *   If the file was compressed in this session, JPEG also shows PSNR.
 *
 * @param {File} file — file uploaded to the Decompress tab
 * @returns {Promise<{ typeLabel: string, message: string, outputBlob: Blob, outputName: string }>}
 */
async function decompressOrInspect(file) {
  const lower = file.name.toLowerCase();

  // ── 1. Raw GZIP (.gz) ──────────────────────────────────────────────────────
  if (lower.endsWith('.gz')) {
    const gzipBytes = new Uint8Array(await file.arrayBuffer());
    let rebuiltBytes;
    try {
      rebuiltBytes = pako.ungzip(gzipBytes);
    } catch {
      throw new Error('Failed to decompress .gz file — corrupt or not a valid GZIP archive.');
    }
    const rebuiltBuffer = rebuiltBytes.buffer.slice(
      rebuiltBytes.byteOffset, rebuiltBytes.byteOffset + rebuiltBytes.byteLength);
    const outputName = file.name.replace(/\.gz$/i, '') || 'recovered-file';
    const blob = new Blob([rebuiltBuffer], { type: guessMimeFromName(outputName) || 'application/octet-stream' });
    const rebuiltHash = await sha256Hex(rebuiltBuffer);

    const storedHash = state.hashStore[file.name];
    const hashSection = storedHash
      ? `<br>Original SHA-256: <code>${storedHash}</code>` +
        `<br>Rebuilt SHA-256:&nbsp; <code>${rebuiltHash}</code>` +
        `<br>Exact match: <strong>${storedHash === rebuiltHash ? '✅ Yes — perfect rebuild' : '❌ No — mismatch'}</strong>`
      : `<br>SHA-256 (rebuilt): <code>${rebuiltHash}</code>` +
        `<br><small>Compare this hash with the original SHA-256 shown on the Compress tab to verify.</small>`;

    return {
      typeLabel: 'GZIP / Lossless',
      message: `Decompressed <strong>${escapeHtml(outputName)}</strong> successfully.<br>` +
               `Compressed: <strong>${formatBytes(file.size)}</strong> → Recovered: <strong>${formatBytes(blob.size)}</strong>` +
               hashSection,
      outputBlob: blob,
      outputName,
    };
  }

  // ── 2. .fcs container (legacy) ─────────────────────────────────────────────
  if (lower.endsWith('.fcs')) {
    let payload;
    try { payload = JSON.parse(await file.text()); }
    catch { throw new Error('Invalid .fcs file — could not parse JSON wrapper.'); }
    if (payload.signature !== 'FCS1') throw new Error('Invalid .fcs file — expected FCS1 signature.');
    const gzipBytes = base64ToBytes(payload.payloadBase64);
    let rebuiltBytes;
    try { rebuiltBytes = pako.ungzip(gzipBytes); }
    catch { throw new Error('Failed to decompress the GZIP payload inside the .fcs archive.'); }
    const rebuiltBuffer = rebuiltBytes.buffer.slice(
      rebuiltBytes.byteOffset, rebuiltBytes.byteOffset + rebuiltBytes.byteLength);
    const rebuiltHash = await sha256Hex(rebuiltBuffer);
    const exactMatch = rebuiltHash === payload.originalHash;
    const blob = new Blob([rebuiltBuffer], { type: payload.originalMime || 'application/octet-stream' });
    return {
      typeLabel: 'FCS Archive',
      message: `Recovered <strong>${escapeHtml(payload.originalName)}</strong><br>` +
               `Original SHA-256: <code>${payload.originalHash}</code><br>` +
               `Rebuilt SHA-256:&nbsp; <code>${rebuiltHash}</code><br>` +
               `Exact match: <strong>${exactMatch ? '✅ Yes — perfect rebuild' : '❌ No — data mismatch'}</strong>`,
      outputBlob: blob,
      outputName: payload.originalName,
    };
  }

  // ── 3. Plain text / CSV ────────────────────────────────────────────────────
  if (lower.endsWith('.txt') || lower.endsWith('.csv')) {
    const rawBytes = new Uint8Array(await file.arrayBuffer());
    if (rawBytes[0] === 0x1f && rawBytes[1] === 0x8b) {
      // Has GZIP magic bytes — decompress it
      let rebuiltBytes;
      try { rebuiltBytes = pako.ungzip(rawBytes); }
      catch { throw new Error('File has GZIP magic bytes but decompression failed — file may be corrupt.'); }
      const rebuiltBuffer = rebuiltBytes.buffer.slice(
        rebuiltBytes.byteOffset, rebuiltBytes.byteOffset + rebuiltBytes.byteLength);
      const blob = new Blob([rebuiltBuffer], { type: guessMimeFromName(file.name) });
      const rebuiltHash = await sha256Hex(rebuiltBuffer);
      const storedHash = state.hashStore[file.name] || state.hashStore[`${file.name}.gz`];
      const hashSection = storedHash
        ? `<br>Original SHA-256: <code>${storedHash}</code>` +
          `<br>Rebuilt SHA-256:&nbsp; <code>${rebuiltHash}</code>` +
          `<br>Exact match: <strong>${storedHash === rebuiltHash ? '✅ Yes' : '❌ No'}</strong>`
        : `<br>SHA-256 (rebuilt): <code>${rebuiltHash}</code>`;
      return {
        typeLabel: 'Text / Lossless',
        message: `Decompressed <strong>${escapeHtml(file.name)}</strong><br>` +
                 `Recovered size: <strong>${formatBytes(blob.size)}</strong>${hashSection}`,
        outputBlob: blob,
        outputName: file.name,
      };
    }
    // Not GZIP — passthrough with a short preview
    const preview = new TextDecoder().decode(rawBytes).slice(0, 300);
    return {
      typeLabel: 'Text / Plain',
      message: `This file is not GZIP-compressed (the compressor kept the original because GZIP would have increased the size).<br><br>` +
               `Size: <strong>${formatBytes(file.size)}</strong><br><br>` +
               `Preview: <code>${escapeHtml(preview)}${rawBytes.length > 300 ? '…' : ''}</code>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 4. PNG — lossless image ────────────────────────────────────────────────
  if (lower.endsWith('.png')) {
    const buffer = await file.arrayBuffer();
    const hash = await sha256Hex(buffer);
    const storedHash = state.hashStore[file.name];

    let dims = '';
    try {
      const bmp = await createImageBitmap(file);
      dims = `Dimensions: <strong>${bmp.width} × ${bmp.height} px</strong><br>`;
      bmp.close();
    } catch { /* non-fatal */ }

    const hashSection = storedHash
      ? `<br>Original SHA-256: <code>${storedHash}</code>` +
        `<br>Rebuilt SHA-256:&nbsp; <code>${hash}</code>` +
        `<br>Exact match: <strong>${storedHash === hash ? '✅ Yes — lossless round-trip confirmed' : '❌ No (UPNG reordered internal chunks; pixels are identical)'}</strong>`
      : `<br>SHA-256: <code>${hash}</code>`;

    return {
      typeLabel: 'PNG / Lossless',
      message: `PNG uses lossless compression — no pixel data is lost.<br>` +
               `${dims}Size: <strong>${formatBytes(file.size)}</strong>${hashSection}<br><br>` +
               `<small>Download the file as-is to use the decompressed PNG.</small>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 5. JPEG — lossy image ──────────────────────────────────────────────────
  // JPEG cannot be reversed to the original. We inspect and report metrics.
  // If the original file was compressed in this session, PSNR is recalculated.
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) {
    let dims = '';
    let psnrLine = '';

    try {
      const bmp = await createImageBitmap(file);
      dims = `Dimensions: <strong>${bmp.width} × ${bmp.height} px</strong><br>`;
      bmp.close();
    } catch { /* non-fatal */ }

    const originalFile = state.originalFileStore[file.name];
    if (originalFile) {
      try {
        const psnr = await calculatePsnrFromImages(originalFile, file);
        const quality = psnr === Infinity
          ? 'Infinite (no change)'
          : `${psnr.toFixed(2)} dB${psnr >= 40 ? ' — excellent' : psnr >= 30 ? ' — good' : ' — noticeable loss'}`;
        psnrLine = `PSNR vs original: <strong>${quality}</strong><br>`;
      } catch { /* non-fatal */ }
    }

    const hash = await sha256Hex(await file.arrayBuffer());
    return {
      typeLabel: 'JPEG / Lossy',
      message: `JPEG uses lossy compression — the original pixels cannot be fully recovered.<br><br>` +
               `${dims}${psnrLine}` +
               `Compressed size: <strong>${formatBytes(file.size)}</strong><br>` +
               `SHA-256: <code>${hash}</code><br><br>` +
               `<small>Download the file as-is to use the compressed JPEG image.</small>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 6. MP3 ─────────────────────────────────────────────────────────────────
  if (lower.endsWith('.mp3')) {
    let durationLabel = 'unknown';
    let kbps = 0;
    try {
      const audioCtx = new AudioContext();
      const buf = await audioCtx.decodeAudioData(await file.arrayBuffer());
      durationLabel = `${buf.duration.toFixed(1)} s`;
      kbps = Math.round((file.size * 8) / 1000 / (buf.duration || 1));
      await audioCtx.close();
    } catch { /* non-fatal */ }
    return {
      typeLabel: 'MP3 / Lossy',
      message: `MP3 is a lossy format — the original PCM audio cannot be recovered.<br><br>` +
               `Duration: <strong>${durationLabel}</strong> &nbsp;|&nbsp; ` +
               `Approx bitrate: <strong>${kbps > 0 ? `${kbps} kbps` : 'N/A'}</strong><br>` +
               `Size: <strong>${formatBytes(file.size)}</strong><br><br>` +
               `<small>Download the file as-is to use the compressed audio.</small>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 7. WAV ─────────────────────────────────────────────────────────────────
  if (lower.endsWith('.wav')) {
    return {
      typeLabel: 'WAV / Uncompressed',
      message: `WAV is uncompressed PCM audio — no decompression is needed.<br>` +
               `Size: <strong>${formatBytes(file.size)}</strong><br><br>` +
               `<small>Download the file as-is.</small>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 8. WebM — output produced by the video compressor ─────────────────────
  if (lower.endsWith('.webm')) {
    const { durationLabel, kbps } = await readVideoDuration(file);
    return {
      typeLabel: 'WebM / Lossy',
      message: `WebM (VP8/VP9 + Opus) is a lossy format — the original source cannot be reconstructed.<br><br>` +
               `Duration: <strong>${durationLabel}</strong> &nbsp;|&nbsp; ` +
               `Approx bitrate: <strong>${kbps > 0 ? `${kbps} kbps` : 'N/A'}</strong><br>` +
               `Size: <strong>${formatBytes(file.size)}</strong><br><br>` +
               `<small>Download the file to play or use the compressed video.</small>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 9. MP4 ─────────────────────────────────────────────────────────────────
  if (lower.endsWith('.mp4')) {
    const { durationLabel, kbps } = await readVideoDuration(file);
    return {
      typeLabel: 'MP4 / Lossy',
      message: `MP4 uses lossy H.264/H.265 compression internally — pixel-perfect reversal is not possible.<br><br>` +
               `Duration: <strong>${durationLabel}</strong> &nbsp;|&nbsp; ` +
               `Approx bitrate: <strong>${kbps > 0 ? `${kbps} kbps` : 'N/A'}</strong><br>` +
               `Size: <strong>${formatBytes(file.size)}</strong><br><br>` +
               `<small>Download the file to play or use the video.</small>`,
      outputBlob: file,
      outputName: file.name,
    };
  }

  // ── 10. Unsupported ────────────────────────────────────────────────────────
  const ext = lower.includes('.') ? lower.split('.').pop() : 'unknown';
  throw new Error(
    `Unsupported file type: .${ext}. ` +
    `Supported formats: .gz  .fcs  .txt  .csv  .png  .jpg  .jpeg  .mp3  .wav  .mp4  .webm`
  );
}

/**
 * Reads video duration and approximate bitrate from a File using a hidden
 * <video> element. Returns safe fallback strings on any failure.
 * @param {File} file
 * @returns {Promise<{ durationLabel: string, kbps: number }>}
 */
async function readVideoDuration(file) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.preload = 'metadata';
    const u = URL.createObjectURL(file);
    v.src = u;
    const done = () => {
      URL.revokeObjectURL(u);
      const d = v.duration;
      const durationLabel = isFinite(d) && d > 0 ? `${d.toFixed(1)} s` : 'unknown';
      const kbps = isFinite(d) && d > 0 ? Math.round((file.size * 8) / 1000 / d) : 0;
      resolve({ durationLabel, kbps });
    };
    v.onloadedmetadata = done;
    v.onerror = done; // resolve with fallback rather than reject
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PSNR calculation
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Calculates Peak Signal-to-Noise Ratio between two image Blobs.
 * ≥40 dB is excellent. ≥30 dB is good. <25 dB is poor.
 * Returns Infinity if the images are pixel-identical.
 * @param {Blob} originalBlob
 * @param {Blob} compressedBlob
 * @returns {Promise<number>}
 */
async function calculatePsnrFromImages(originalBlob, compressedBlob) {
  const [origBmp, compBmp] = await Promise.all([
    createImageBitmap(originalBlob),
    createImageBitmap(compressedBlob),
  ]);
  const width = Math.min(origBmp.width, compBmp.width);
  const height = Math.min(origBmp.height, compBmp.height);

  const origCanvas = new OffscreenCanvas(width, height);
  const compCanvas = new OffscreenCanvas(width, height);
  const origCtx = origCanvas.getContext('2d');
  const compCtx = compCanvas.getContext('2d');
  if (!origCtx || !compCtx) return null;

  origCtx.drawImage(origBmp, 0, 0, width, height);
  compCtx.drawImage(compBmp, 0, 0, width, height);

  const origPx = origCtx.getImageData(0, 0, width, height).data;
  const compPx = compCtx.getImageData(0, 0, width, height).data;

  let mse = 0;
  for (let i = 0; i < origPx.length; i += 4) {
    mse += (origPx[i]     - compPx[i])     ** 2;
    mse += (origPx[i + 1] - compPx[i + 1]) ** 2;
    mse += (origPx[i + 2] - compPx[i + 2]) ** 2;
  }
  mse /= (width * height * 3);
  return mse === 0 ? Infinity : 10 * Math.log10((255 * 255) / mse);
}

// ─────────────────────────────────────────────────────────────────────────────
// SHA-256
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Computes a hex SHA-256 digest using the SubtleCrypto API.
 * The input must be a plain ArrayBuffer, not a typed array view.
 * @param {ArrayBuffer} arrayBuffer
 * @returns {Promise<string>}
 */
async function sha256Hex(arrayBuffer) {
  const hashBuf = await crypto.subtle.digest('SHA-256', arrayBuffer);
  return [...new Uint8Array(hashBuf)]
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

// ─────────────────────────────────────────────────────────────────────────────
// Utility helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Decodes a Base64 string to a Uint8Array.
 * @param {string} base64
 * @returns {Uint8Array}
 */
function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

/**
 * Formats a byte count as a human-readable string.
 * @param {number} bytes
 * @returns {string}
 */
function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const exp = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** exp).toFixed(exp === 0 ? 0 : 2)} ${units[exp]}`;
}

/**
 * Formats a compression ratio as "X.XX : 1".
 * @param {number} originalSize
 * @param {number} compressedSize
 * @returns {string}
 */
function formatCompressionRatio(originalSize, compressedSize) {
  if (!compressedSize) return '∞';
  return `${(originalSize / compressedSize).toFixed(2)} : 1`;
}

/**
 * Calculates and formats the percentage of space saved.
 * @param {number} originalSize
 * @param {number} compressedSize
 * @returns {string}
 */
function formatSpaceSavings(originalSize, compressedSize) {
  const savings = Math.max(0, ((originalSize - compressedSize) / originalSize) * 100);
  return `${savings.toFixed(2)}%`;
}

/**
 * Estimates media bitrate from file size alone (no duration available).
 * @param {File} file
 * @returns {string}
 */
function guessMediaBitrate(file) {
  return `${Math.max(64, Math.round((file.size * 8) / 1000))} kbps approx`;
}

/**
 * Builds an output filename by replacing the last extension with a suffix.
 * Example: buildOutputName('photo.jpg', 'compressed.jpg') → 'photo-compressed.jpg'
 * @param {string} originalName
 * @param {string} suffix
 * @returns {string}
 */
function buildOutputName(originalName, suffix) {
  return `${originalName.replace(/\.[^.]+$/, '')}-${suffix}`;
}

/**
 * Maps a filename extension to a MIME type string.
 * @param {string} fileName
 * @returns {string}
 */
function guessMimeFromName(fileName) {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.txt'))                             return 'text/plain';
  if (lower.endsWith('.csv'))                             return 'text/csv';
  if (lower.endsWith('.png'))                             return 'image/png';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.wav'))                             return 'audio/wav';
  if (lower.endsWith('.mp3'))                             return 'audio/mpeg';
  if (lower.endsWith('.mp4'))                             return 'video/mp4';
  if (lower.endsWith('.webm'))                            return 'video/webm';
  return 'application/octet-stream';
}

/**
 * Escapes HTML special characters to prevent XSS in innerHTML assignments.
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Triggers a browser file download for a Blob.
 * @param {Blob} blob
 * @param {string} filename
 */
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Resets only compression-related state and hides the compression result panel. */
function resetCompressionState() {
  state.compressedBlob = null;
  state.decompressedBlob = null;
  state.compressedName = '';
  state.decompressedName = '';
  elements.resultsPanel.classList.add('hidden');
  elements.downloadCompressed.disabled = true;
  elements.downloadDecompressed.disabled = true;
  elements.verificationList.innerHTML = '';
}

/** Resets only decompression-related state and hides the decompression result panel. */
function resetDecompressionState() {
  state.processedBlob = null;
  state.processedName = '';
  elements.decompressPanel.classList.add('hidden');
  elements.downloadProcessed.disabled = true;
  elements.decompressOutput.innerHTML = '';
  elements.decompressBadge.textContent = '—';
}

/**
 * Updates the status bar message.
 * @param {string} message
 */
function setStatus(message) {
  elements.status.textContent = message;
}

/**
 * Shows a user-facing error in the error box.
 * @param {string} message
 */
function showError(message) {
  elements.errorBox.classList.remove('hidden');
  elements.errorBox.textContent = message;
}

/** Clears and hides the error box. */
function clearError() {
  elements.errorBox.classList.add('hidden');
  elements.errorBox.textContent = '';
}
