chrome.runtime.onInstalled.addListener(() => {
  console.log('File Compression Studio installed.');
});
